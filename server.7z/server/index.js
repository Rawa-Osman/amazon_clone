//import from pachages
const express = require("express");
const mongoose = require("mongoose");

//import from other files
const authRoute = require("./routes/auth.js");

//import './features/auth/screens/auth_screen.dart';

//INIT
const PORT = 3000;
const app = express();
const DB = "mongodb://rawa:rawa1234@ac-vllfk6e-shard-00-00.9zmucyw.mongodb.net:27017,ac-vllfk6e-shard-00-01.9zmucyw.mongodb.net:27017,ac-vllfk6e-shard-00-02.9zmucyw.mongodb.net:27017/?ssl=true&replicaSet=atlas-rh7mwf-shard-0&authSource=admin&retryWrites=true&w=majority";


// middleware
// clinet -> (middleware) -> server -> clinet
app.use(authRoute);

// connection
mongoose
  .connect(DB)
  .then(() => {
    console.log("connection successful");
  })
  .catch((e) => {
    console.log(e);
  });

app.listen(PORT, () => {
  console.log(`connectd at ${PORT}`);
});
