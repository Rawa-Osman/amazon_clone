const express = require('express');
const { default: mongoose } = require('mongoose');

const authRoute = express.Router();

authRoute.post('/api/singup',(req,res)=>{
    //get the data from client
    const {name,email,password}= req.body;

    //post that data in database
    //return that data to the user
});


module.exports= authRoute;


